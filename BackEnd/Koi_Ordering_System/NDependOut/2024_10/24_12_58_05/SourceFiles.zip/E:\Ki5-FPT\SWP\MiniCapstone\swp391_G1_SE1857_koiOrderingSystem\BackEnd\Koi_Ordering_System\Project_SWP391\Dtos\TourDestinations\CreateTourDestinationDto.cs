﻿namespace Project_SWP391.Dtos.TourDestinations
{
    public class CreateTourDestinationDto
    {
        public string Type { get; set; }
    }
}
