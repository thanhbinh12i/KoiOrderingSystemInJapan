﻿namespace Project_SWP391.Dtos.KoiVarieties
{
    public class CreateKoiVarietyDto
    {
        public string VarietyName { get; set; }
        public string Description { get; set; }
    }
}
