﻿namespace Project_SWP391.Dtos.Ratings
{
    public class UpdateRatingDto
    {
        public int Rate { get; set; }
        public string Content { get; set; }
    }
}
