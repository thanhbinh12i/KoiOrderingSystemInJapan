﻿namespace Project_SWP391.Dtos.KoiBills
{
    public class CreateKoiBillDto
    {
        public float? OriginalPrice { get; set; }
        public int? Quantity { get; set; }
        public float? FinalPrice { get; set; }
    }
}
