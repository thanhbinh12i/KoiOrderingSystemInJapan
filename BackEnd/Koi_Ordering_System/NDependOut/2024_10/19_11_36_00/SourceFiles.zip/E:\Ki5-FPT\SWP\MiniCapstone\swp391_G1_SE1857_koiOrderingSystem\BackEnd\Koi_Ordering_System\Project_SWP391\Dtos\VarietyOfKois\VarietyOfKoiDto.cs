﻿using Project_SWP391.Model;

namespace Project_SWP391.Dtos.VarietyOfKois
{
    public class VarietyOfKoiDto
    {
        public int VarietyId { get; set; }
        public int KoiId { get; set; }
    }
}
