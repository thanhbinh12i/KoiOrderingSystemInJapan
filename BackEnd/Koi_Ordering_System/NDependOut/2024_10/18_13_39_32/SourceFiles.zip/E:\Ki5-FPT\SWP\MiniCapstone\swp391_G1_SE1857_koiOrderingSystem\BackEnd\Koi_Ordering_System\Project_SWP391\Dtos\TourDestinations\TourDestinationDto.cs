﻿using Project_SWP391.Model;

namespace Project_SWP391.Dtos.TourDestinations
{
    public class TourDestinationDto
    {
        public int FarmId { get; set; }
        public int TourId { get; set; }
        public string Type { get; set; }
    }
}
