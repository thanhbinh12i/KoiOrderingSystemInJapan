﻿namespace Project_SWP391.Dtos.FarmImages
{
    public class CreateFarmImageDto
    {
        public string UrlImage { get; set; }
    }
}
