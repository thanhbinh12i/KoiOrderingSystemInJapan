﻿namespace Project_SWP391.Dtos.FarmImages
{
    public class UpdateFarmImageDto
    {
        public string UrlImage { get; set; }
    }
}
