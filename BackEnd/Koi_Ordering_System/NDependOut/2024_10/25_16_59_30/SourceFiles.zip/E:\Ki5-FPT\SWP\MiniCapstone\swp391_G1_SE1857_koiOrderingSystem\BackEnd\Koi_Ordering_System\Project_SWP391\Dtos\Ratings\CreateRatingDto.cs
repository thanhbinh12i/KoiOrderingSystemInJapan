﻿namespace Project_SWP391.Dtos.Ratings
{
    public class CreateRatingDto
    {
        public float Rate { get; set; }
        public string Content { get; set; }
        public string RatingDate { get; set; }
    }
}
