﻿namespace Project_SWP391.Dtos.Bills
{
    public class UpdateBillDto
    {
        public float Price { get; set; }
    }
}
