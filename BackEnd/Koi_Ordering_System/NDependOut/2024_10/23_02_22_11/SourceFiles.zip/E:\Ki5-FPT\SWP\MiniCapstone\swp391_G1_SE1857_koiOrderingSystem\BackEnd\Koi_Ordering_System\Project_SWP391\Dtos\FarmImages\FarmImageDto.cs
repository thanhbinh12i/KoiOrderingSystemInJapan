﻿namespace Project_SWP391.Dtos.FarmImages
{
    public class FarmImageDto
    {
        public int ImageId { get; set; }
        public string UrlImage { get; set; }
        public int? FarmId { get; set; }
    }
}
