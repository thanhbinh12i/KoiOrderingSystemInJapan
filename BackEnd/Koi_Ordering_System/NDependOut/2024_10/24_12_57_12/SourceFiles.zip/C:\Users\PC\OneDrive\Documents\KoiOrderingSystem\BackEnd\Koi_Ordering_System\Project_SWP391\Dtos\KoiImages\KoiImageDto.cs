﻿namespace Project_SWP391.Dtos.KoiImages
{
    public class KoiImageDto
    {
        public int ImageId { get; set; }
        public string Url { get; set; }
        public int KoiId { get; set; }
    }
}
