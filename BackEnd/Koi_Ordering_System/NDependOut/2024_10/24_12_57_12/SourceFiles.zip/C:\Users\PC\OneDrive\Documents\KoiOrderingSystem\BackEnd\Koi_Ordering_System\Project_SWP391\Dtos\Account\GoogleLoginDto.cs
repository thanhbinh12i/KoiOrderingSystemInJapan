﻿namespace Project_SWP391.Dtos.Account
{
    public class GoogleLoginDto
    {
        public string Token { get; set; }
    }
}
