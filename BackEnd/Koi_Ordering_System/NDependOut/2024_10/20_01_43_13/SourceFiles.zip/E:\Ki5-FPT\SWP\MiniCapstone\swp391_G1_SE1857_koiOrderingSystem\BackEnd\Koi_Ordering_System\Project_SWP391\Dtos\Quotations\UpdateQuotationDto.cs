﻿namespace Project_SWP391.Dtos.Quotations
{
    public class UpdateQuotationDto
    {
        public float PriceOffer { get; set; }
        public string Status { get; set; }
        public string ApprovedDate { get; set; }
        public string Description { get; set; }

    }
}
