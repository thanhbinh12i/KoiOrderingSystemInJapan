﻿namespace Project_SWP391.Dtos.Bills
{
    public class UpdateBillDto
    {
        public string UserFullName { get; set; }
        public float Price { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }
}
