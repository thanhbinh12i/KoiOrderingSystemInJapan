﻿namespace Project_SWP391.Dtos.VarietyOfKois
{
    public class CreateVarietyOfKoiDto
    {
    }
}
