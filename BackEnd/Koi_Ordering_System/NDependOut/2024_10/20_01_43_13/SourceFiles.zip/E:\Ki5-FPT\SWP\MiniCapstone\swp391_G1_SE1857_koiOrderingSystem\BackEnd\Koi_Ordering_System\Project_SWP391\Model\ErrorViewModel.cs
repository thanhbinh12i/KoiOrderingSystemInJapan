﻿namespace Project_SWP391.Model
{
    public class ErrorViewModel
    {
        public string RspCode { get; set; }

        public string Message { get; set; }
    }
}
