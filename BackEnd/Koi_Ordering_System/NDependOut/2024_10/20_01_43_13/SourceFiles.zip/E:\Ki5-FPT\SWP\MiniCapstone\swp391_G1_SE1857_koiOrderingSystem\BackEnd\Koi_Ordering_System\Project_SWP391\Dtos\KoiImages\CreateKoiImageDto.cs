﻿namespace Project_SWP391.Dtos.KoiImages
{
    public class CreateKoiImageDto
    {
        public string Url { get; set; }
    }
}
