﻿namespace Project_SWP391.Dtos.KoiBills
{
    public class UpdateKoiBillDto
    {
        public float? OriginalPrice { get; set; }
        public int? Quantity { get; set; }
        public float? FinalPrice { get; set; }
    }
}
