﻿namespace Project_SWP391.Dtos.Bills
{
    public class UpdateBillDto
    {
        public float? KoiPrice { get; set; }
        public float? TotalPrice { get; set; }
        public string PaymentDate { get; set; }
    }
}
