﻿namespace Project_SWP391.Dtos.Feedbacks
{
    public class CreateFeedbackDto
    {
        public float Rating { get; set; }
        public string Content { get; set; }
    }
}
