﻿namespace Project_SWP391.Dtos.TourDestinations
{
    public class UpdateTourDestinationDto
    {
        public string Type { get; set; }
    }
}
