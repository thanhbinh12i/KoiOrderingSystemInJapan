﻿namespace Project_SWP391.Dtos.KoiImages
{
    public class UpdateKoiImageDto
    {
        public string Url { get; set; }
        public int KoiId { get; set; }
    }
}
