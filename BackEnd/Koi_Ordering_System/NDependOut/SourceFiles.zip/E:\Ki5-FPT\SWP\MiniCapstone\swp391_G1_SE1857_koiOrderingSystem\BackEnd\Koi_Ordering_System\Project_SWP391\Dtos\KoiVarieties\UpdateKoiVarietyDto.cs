﻿namespace Project_SWP391.Dtos.KoiVarieties
{
    public class UpdateKoiVarietyDto
    {
        public string VarietyName { get; set; }
        public string Description { get; set; }
        public string UrlImage { get; set; }
    }
}
